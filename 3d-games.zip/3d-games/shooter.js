const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b1026);
scene.fog = new THREE.Fog(0x0b1026, 30, 120);
const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.1, 300);
camera.position.set(0, 3, 10);
camera.lookAt(0, 3, 0);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(innerWidth, innerHeight);
document.body.appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xffffff, 0x222244, 0.9));
const sun = new THREE.DirectionalLight(0xffffff, 0.7);
sun.position.set(5, 15, 10);
scene.add(sun);

const ground = new THREE.Mesh(new THREE.PlaneGeometry(300, 300), new THREE.MeshLambertMaterial({ color: 0x1f3b2d }));
ground.rotation.x = -Math.PI / 2; scene.add(ground);

// sajawat ke liye khambe
const pillarGeo = new THREE.BoxGeometry(2, 12, 2);
const pillarMat = new THREE.MeshLambertMaterial({ color: 0x3d4a7a });
for (let i = 0; i < 24; i++) {
  const p = new THREE.Mesh(pillarGeo, pillarMat);
  p.position.set((Math.random() < 0.5 ? -1 : 1) * (25 + Math.random() * 30), 6, -Math.random() * 150);
  scene.add(p);
}

const enemies = [];
const enemyGeo = new THREE.SphereGeometry(1, 20, 20);
let score = 0, lives = 5, spawnTimer = 0, running = true;
const scoreEl = document.getElementById('score');
const livesEl = document.getElementById('lives');
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();

addEventListener('pointerdown', e => {
  if (!running || e.target.tagName === 'BUTTON' || e.target.tagName === 'A') return;
  mouse.x = (e.clientX / innerWidth) * 2 - 1;
  mouse.y = -(e.clientY / innerHeight) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);
  const hits = raycaster.intersectObjects(enemies);
  if (hits.length) {
    const m = hits[0].object;
    scene.remove(m);
    enemies.splice(enemies.indexOf(m), 1);
    score++; scoreEl.textContent = score;
  }
});

function gameOver() {
  running = false;
  document.getElementById('msgtext').innerHTML = 'Game Over!<br>Score: ' + score;
  document.getElementById('msg').style.display = 'flex';
}

const clock = new THREE.Clock();
function loop() {
  requestAnimationFrame(loop);
  const dt = Math.min(clock.getDelta(), 0.05);
  if (running) {
    spawnTimer -= dt;
    if (spawnTimer <= 0) {
      const m = new THREE.Mesh(enemyGeo, new THREE.MeshLambertMaterial({ color: 0xff3b3b }));
      m.position.set((Math.random() - 0.5) * 36, 1 + Math.random() * 7, -90);
      m.userData.speed = 10 + Math.random() * 6 + score * 0.15;
      scene.add(m); enemies.push(m);
      spawnTimer = Math.max(0.35, 1.1 - score * 0.02);
    }
    for (let i = enemies.length - 1; i >= 0; i--) {
      const m = enemies[i];
      m.position.z += m.userData.speed * dt;
      if (m.position.z > 9) {
        scene.remove(m); enemies.splice(i, 1);
        lives--; livesEl.textContent = lives;
        if (lives <= 0) gameOver();
      }
    }
  }
  renderer.render(scene, camera);
}
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});
loop();
