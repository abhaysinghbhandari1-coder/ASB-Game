const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb);
scene.fog = new THREE.Fog(0x87ceeb, 30, 160);
const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.1, 300);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(innerWidth, innerHeight);
document.body.appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xffffff, 0x555555, 0.9));
const sun = new THREE.DirectionalLight(0xffffff, 0.6);
sun.position.set(5, 10, 5);
scene.add(sun);

// zameen + sadak
const ground = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), new THREE.MeshLambertMaterial({ color: 0x3a9d3a }));
ground.rotation.x = -Math.PI / 2; ground.position.y = -0.05; scene.add(ground);
const road = new THREE.Mesh(new THREE.PlaneGeometry(12, 400), new THREE.MeshLambertMaterial({ color: 0x333333 }));
road.rotation.x = -Math.PI / 2; road.position.z = -150; scene.add(road);

// lane ki safed lines (peeche ki taraf aati rehti hain)
const marks = [];
const markGeo = new THREE.BoxGeometry(0.2, 0.02, 4);
const markMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
for (let i = 0; i < 20; i++) {
  [-2, 2].forEach(x => {
    const m = new THREE.Mesh(markGeo, markMat);
    m.position.set(x, 0.03, -i * 10);
    scene.add(m); marks.push(m);
  });
}

function makeCar(color) {
  const g = new THREE.Group();
  const body = new THREE.Mesh(new THREE.BoxGeometry(2, 0.8, 4), new THREE.MeshLambertMaterial({ color }));
  body.position.y = 0.7; g.add(body);
  const cab = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.7, 2), new THREE.MeshLambertMaterial({ color: 0x222222 }));
  cab.position.set(0, 1.4, 0.2); g.add(cab);
  const wg = new THREE.CylinderGeometry(0.4, 0.4, 0.3, 16);
  const wm = new THREE.MeshLambertMaterial({ color: 0x111111 });
  [[-1.05, 1.3], [1.05, 1.3], [-1.05, -1.3], [1.05, -1.3]].forEach(p => {
    const w = new THREE.Mesh(wg, wm);
    w.rotation.z = Math.PI / 2; w.position.set(p[0], 0.4, p[1]); g.add(w);
  });
  return g;
}

const player = makeCar(0xe53935);
scene.add(player);

const keys = {};
let touchDir = 0;
addEventListener('keydown', e => keys[e.code] = true);
addEventListener('keyup', e => keys[e.code] = false);
addEventListener('pointerdown', e => { touchDir = e.clientX < innerWidth / 2 ? -1 : 1; });
addEventListener('pointerup', () => { touchDir = 0; });

const enemies = [];
const lanes = [-4, 0, 4];
const colors = [0x1e88e5, 0xfdd835, 0x8e24aa, 0xff7043, 0x43a047];
let speed = 30, score = 0, spawnTimer = 0, running = true;
const clock = new THREE.Clock();
const scoreEl = document.getElementById('score');

function gameOver() {
  running = false;
  document.getElementById('msgtext').innerHTML = 'Game Over!<br>Score: ' + Math.floor(score);
  document.getElementById('msg').style.display = 'flex';
}

function loop() {
  requestAnimationFrame(loop);
  const dt = Math.min(clock.getDelta(), 0.05);
  if (running) {
    let dir = 0;
    if (keys.ArrowLeft || keys.KeyA) dir -= 1;
    if (keys.ArrowRight || keys.KeyD) dir += 1;
    if (touchDir) dir = touchDir;
    player.position.x = THREE.MathUtils.clamp(player.position.x + dir * 12 * dt, -5, 5);
    player.rotation.y = -dir * 0.15;

    speed += dt * 0.8;
    score += speed * dt * 0.1;
    scoreEl.textContent = Math.floor(score);

    marks.forEach(m => { m.position.z += speed * dt; if (m.position.z > 20) m.position.z -= 200; });

    spawnTimer -= dt;
    if (spawnTimer <= 0) {
      const c = makeCar(colors[Math.floor(Math.random() * colors.length)]);
      c.position.set(lanes[Math.floor(Math.random() * 3)], 0, -150);
      scene.add(c); enemies.push(c);
      spawnTimer = Math.max(0.4, 1.2 - score * 0.002);
    }

    for (let i = enemies.length - 1; i >= 0; i--) {
      const e = enemies[i];
      e.position.z += (speed * 0.5) * dt;   // dushman gaadiyan dheere chalti hain
      if (Math.abs(e.position.x - player.position.x) < 1.9 && Math.abs(e.position.z) < 3.8) gameOver();
      if (e.position.z > 15) { scene.remove(e); enemies.splice(i, 1); }
    }
  }
  camera.position.set(player.position.x * 0.6, 5, 9);
  camera.lookAt(player.position.x * 0.3, 1, -10);
  renderer.render(scene, camera);
}
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});
loop();
