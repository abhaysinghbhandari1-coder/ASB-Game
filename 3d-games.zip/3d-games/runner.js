const scene = new THREE.Scene();
scene.background = new THREE.Color(0x1b2a49);
scene.fog = new THREE.Fog(0x1b2a49, 20, 120);
const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.1, 300);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(innerWidth, innerHeight);
document.body.appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xffffff, 0x333355, 0.9));
const sun = new THREE.DirectionalLight(0xffffff, 0.6);
sun.position.set(4, 10, 6);
scene.add(sun);

const road = new THREE.Mesh(new THREE.PlaneGeometry(9, 400), new THREE.MeshLambertMaterial({ color: 0x2e3b55 }));
road.rotation.x = -Math.PI / 2; road.position.z = -150; scene.add(road);

const marks = [];
const markGeo = new THREE.BoxGeometry(0.15, 0.02, 3);
const markMat = new THREE.MeshBasicMaterial({ color: 0x8fb3ff });
for (let i = 0; i < 20; i++) {
  [-1.5, 1.5].forEach(x => {
    const m = new THREE.Mesh(markGeo, markMat);
    m.position.set(x, 0.03, -i * 10);
    scene.add(m); marks.push(m);
  });
}

const player = new THREE.Mesh(new THREE.BoxGeometry(1, 1.5, 1), new THREE.MeshLambertMaterial({ color: 0x29b6f6 }));
scene.add(player);

const lanes = [-3, 0, 3];
let lane = 1, py = 0, vy = 0, onGround = true;
let speed = 25, score = 0, spawnTimer = 0, running = true;
const items = [];
const obsGeo = new THREE.BoxGeometry(2, 1.4, 1);
const obsMat = new THREE.MeshLambertMaterial({ color: 0xe53935 });
const coinGeo = new THREE.CylinderGeometry(0.5, 0.5, 0.12, 20);
const coinMat = new THREE.MeshLambertMaterial({ color: 0xffd600 });
const scoreEl = document.getElementById('score');

function moveLeft() { lane = Math.max(0, lane - 1); }
function moveRight() { lane = Math.min(2, lane + 1); }
function jump() { if (onGround) { vy = 14; onGround = false; } }

addEventListener('keydown', e => {
  if (e.code === 'ArrowLeft' || e.code === 'KeyA') moveLeft();
  if (e.code === 'ArrowRight' || e.code === 'KeyD') moveRight();
  if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') jump();
});
addEventListener('pointerdown', e => {
  if (e.target.tagName === 'BUTTON' || e.target.tagName === 'A') return;
  const x = e.clientX / innerWidth;
  if (x < 0.33) moveLeft(); else if (x > 0.66) moveRight(); else jump();
});

function gameOver() {
  running = false;
  document.getElementById('msgtext').innerHTML = 'Game Over!<br>Score: ' + Math.floor(score);
  document.getElementById('msg').style.display = 'flex';
}

const clock = new THREE.Clock();
function loop() {
  requestAnimationFrame(loop);
  const dt = Math.min(clock.getDelta(), 0.05);
  if (running) {
    speed += dt * 0.6;
    score += speed * dt * 0.05;

    player.position.x += (lanes[lane] - player.position.x) * Math.min(1, dt * 14);
    vy -= 35 * dt; py += vy * dt;
    if (py <= 0) { py = 0; vy = 0; onGround = true; }
    player.position.y = py + 0.75;

    marks.forEach(m => { m.position.z += speed * dt; if (m.position.z > 20) m.position.z -= 200; });

    spawnTimer -= dt;
    if (spawnTimer <= 0) {
      const isCoin = Math.random() < 0.35;
      const mesh = new THREE.Mesh(isCoin ? coinGeo : obsGeo, isCoin ? coinMat : obsMat);
      if (isCoin) { mesh.rotation.x = Math.PI / 2; mesh.position.set(lanes[Math.floor(Math.random() * 3)], 1.2, -120); }
      else mesh.position.set(lanes[Math.floor(Math.random() * 3)], 0.7, -120);
      mesh.userData.coin = isCoin;
      scene.add(mesh); items.push(mesh);
      spawnTimer = Math.max(0.35, 0.9 - score * 0.003);
    }

    for (let i = items.length - 1; i >= 0; i--) {
      const it = items[i];
      it.position.z += speed * dt;
      const hitX = Math.abs(it.position.x - player.position.x) < 1.0;
      const hitZ = Math.abs(it.position.z) < 1.0;
      if (hitX && hitZ) {
        if (it.userData.coin) { score += 10; scene.remove(it); items.splice(i, 1); continue; }
        else if (py < 1.4) gameOver();
      }
      if (it.position.z > 12) { scene.remove(it); items.splice(i, 1); }
    }
    scoreEl.textContent = Math.floor(score);
  }
  camera.position.set(player.position.x * 0.5, 4.5, 8);
  camera.lookAt(player.position.x * 0.3, 1, -6);
  renderer.render(scene, camera);
}
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});
loop();
